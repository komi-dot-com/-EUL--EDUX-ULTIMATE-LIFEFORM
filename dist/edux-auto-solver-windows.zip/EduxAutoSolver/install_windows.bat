@echo off
chcp 65001 >nul
set "SRC=%~dp0"
if "%SRC:~-1%"=="\" set "SRC=%SRC:~0,-1%"
set "DEST=%LOCALAPPDATA%\EduxAutoSolver"

echo ============================================================
echo   CAI DAT EDUX AUTO-SOLVER TREN WINDOWS
echo ============================================================
echo [*] Dang cai dat vao: %DEST%
if not exist "%DEST%" mkdir "%DEST%"
robocopy "%SRC%" "%DEST%" /E /XD chrome_profile /NFL /NDL /NJH /NJS >nul

echo [*] Dang tao shortcut tren Desktop...
powershell -NoProfile -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%USERPROFILE%\Desktop\Edux Auto-Solver.lnk');$s.TargetPath='%DEST%\run.bat';$s.WorkingDirectory='%DEST%';$s.Save()"

echo [OK] Cai dat hoan tat! Ban co the mo 'Edux Auto-Solver' ngay tren Desktop.
pause
