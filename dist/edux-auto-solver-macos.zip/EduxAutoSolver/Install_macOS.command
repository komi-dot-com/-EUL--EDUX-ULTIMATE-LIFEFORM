#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.local/share/edux-auto-solver"

echo "============================================================"
echo "  CAI DAT EDUX AUTO-SOLVER TREN MACOS"
echo "============================================================"
mkdir -p "$DEST"
cp -R "$DIR/Edux Auto-Solver.app/Contents/Resources/app/." "$DEST/"
chmod +x "$DEST/run(dành cho macbook).sh" "$DEST/run(dành cho macbook).command"

cp -R "$DIR/Edux Auto-Solver.app" "/Applications/Edux Auto-Solver.app" 2>/dev/null || cp -R "$DIR/Edux Auto-Solver.app" "$HOME/Applications/Edux Auto-Solver.app"
xattr -cr "/Applications/Edux Auto-Solver.app" 2>/dev/null || true
xattr -cr "$DEST" 2>/dev/null || true

echo "[OK] Cai dat hoan tat! Mo 'Edux Auto-Solver' trong Applications hoac Launchpad."
read -p "Nhan Enter de dong..."
